#!/usr/bin/env python3
"""A tiny multiplayer country-guessing Telegram bot; stdlib only."""
from __future__ import annotations

import json
import os
import random
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

def flag_for(iso: str) -> str:
    return "".join(chr(127397 + ord(letter)) for letter in iso.upper())


def load_countries() -> list[dict]:
    data_file = Path(__file__).resolve().parent / "data" / "countries.json"
    try:
        records = json.loads(data_file.read_text(encoding="utf-8"))
        countries = []
        seen = set()
        for row in records:
            iso = row["iso"].upper()
            name = row.get("name_ru") or row["name"]
            capital = row["capital"]
            if len(iso) != 2 or iso in seen or not name or not isinstance(capital, str):
                raise ValueError(f"Некорректная запись страны: {row!r}")
            seen.add(iso)
            countries.append({"iso": iso.lower(), "name": name, "flag": flag_for(iso), "capital": capital})
        if len(countries) < 200:
            raise ValueError(f"В data/countries.json найдено слишком мало стран: {len(countries)}")
        return countries
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise RuntimeError(f"Не удалось загрузить список стран: {data_file}. Распакуйте вместе с ботом папку data.") from exc


COUNTRIES = load_countries()

API = "https://api.telegram.org/bot{}/{}"
GAMES: dict[int, dict] = {}
ALLOWED_USERS: set[int] = set()


def call(token: str, method: str, data: dict | None = None) -> dict:
    body = urllib.parse.urlencode(data or {}).encode()
    req = urllib.request.Request(API.format(token, method), data=body)
    try:
        with urllib.request.urlopen(req, timeout=40) as response:
            result = json.loads(response.read())
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        print(f"Telegram API error: {exc}")
        return {}
    if not result.get("ok"):
        print(f"Telegram API error: {result}")
        return {}
    return result


MAIN_MENU_KEYBOARD = {
    "inline_keyboard": [
        [{"text": "▶️ Начать игру", "callback_data": "start"}, {"text": "🏆 Счёт", "callback_data": "menu_score"}],
    ]
}
MODE_MENU_KEYBOARD = {
    "inline_keyboard": [
        [{"text": "🎮 Игра вдвоём", "callback_data": "newgame"}, {"text": "👤 Одиночная игра", "callback_data": "solo"}],
        [{"text": "↩️ Назад", "callback_data": "back_menu"}],
    ]
}
GAME_KEYBOARD = {
    "inline_keyboard": [
        [{"text": "💡 Подсказка", "callback_data": "hint"}, {"text": "🏆 Счёт", "callback_data": "score"}],
        [{"text": "⏭ Дальше", "callback_data": "next"}, {"text": "🛑 Стоп", "callback_data": "stop"}],
    ]
}
SOLO_LEVEL_KEYBOARD = {
    "inline_keyboard": [
        [{"text": "🌱 Начальный", "callback_data": "level_easy"}, {"text": "🌿 Средний", "callback_data": "level_medium"}],
        [{"text": "🔥 Продвинутый", "callback_data": "level_hard"}, {"text": "🌍 Все флаги", "callback_data": "level_all"}],
    ]
}
BUTTON_COMMANDS = {
    "start": "/choose_mode",
    "menu_score": "/menu_score",
    "back_menu": "/main_menu",
    "newgame": "/newgame",
    "solo": "/solo",
    "level_easy": "/solo_easy",
    "level_medium": "/solo_medium",
    "level_hard": "/solo_hard",
    "level_all": "/solo_all",
    "hint": "/hint",
    "score": "/score",
    "next": "/next",
    "stop": "/stop",
}


def send(token: str, chat_id: int, text: str, keyboard: dict | None = None) -> dict:
    payload = {"chat_id": chat_id, "text": text}
    if keyboard is not None:
        payload["reply_markup"] = json.dumps(keyboard, ensure_ascii=False)
    return call(token, "sendMessage", payload)


TERRITORY_ISO = set("ai as aw ax bl bq cc ck cw cx eh fk fo gf gg gs gu hk hm im io je ky mf mq ms nc nf nu pf pm pn pr re sj sx tc tk um vg vi wf yt".split())
EASY_ISO = set("jp br is eg ca it au ke gr mx no ma th pe kr ch pt nz tr ar gb fr de es us cn in ru".split())


def difficulty_pool(round_number: int) -> tuple[str, list[dict]]:
    if round_number <= 5:
        return "Лёгкая", [c for c in COUNTRIES if c["iso"] in EASY_ISO]
    if round_number <= 15:
        return "Средняя", [c for c in COUNTRIES if c["iso"] not in EASY_ISO and c["iso"] not in TERRITORY_ISO]
    return "Сложная", [c for c in COUNTRIES if c["iso"] in TERRITORY_ISO]


def solo_pool(level_key: str) -> tuple[str, list[dict]]:
    pools = {
        "easy": ("Начальный", [c for c in COUNTRIES if c["iso"] in EASY_ISO]),
        "medium": ("Средний", [c for c in COUNTRIES if c["iso"] not in EASY_ISO and c["iso"] not in TERRITORY_ISO]),
        "hard": ("Продвинутый", [c for c in COUNTRIES if c["iso"] in TERRITORY_ISO]),
        "all": ("Все флаги", COUNTRIES[:]),
    }
    return pools[level_key]


def solo_round_pool(level_key: str, used: set[str]) -> tuple[str, list[dict]]:
    if level_key != "all":
        return solo_pool(level_key)
    tiers = [
        ("Все флаги • начальный этап", [c for c in COUNTRIES if c["iso"] in EASY_ISO]),
        ("Все флаги • средний этап", [c for c in COUNTRIES if c["iso"] not in EASY_ISO and c["iso"] not in TERRITORY_ISO]),
        ("Все флаги • продвинутый этап", [c for c in COUNTRIES if c["iso"] in TERRITORY_ISO]),
    ]
    for label, tier in tiers:
        if any(c["iso"] not in used for c in tier):
            return label, tier
    return "Все флаги", []


def solo_answer_keyboard(options: list[dict]) -> dict:
    rows = [[{"text": item["name"], "callback_data": f"solo_answer:{item['iso']}"} for item in options[:2]],
            [{"text": item["name"], "callback_data": f"solo_answer:{item['iso']}"} for item in options[2:4]],
            [{"text": "💡 Подсказка", "callback_data": "hint"}, {"text": "⏭ Дальше", "callback_data": "next"}, {"text": "🛑 Стоп", "callback_data": "stop"}]]
    return {"inline_keyboard": rows}


def start_solo_round(token: str, chat_id: int, game: dict) -> None:
    level_name, pool = solo_round_pool(game["level"], game["used"])
    unused = [c for c in pool if c["iso"] not in game["used"]]
    if not unused:
        game["finished"] = True
        total = len(COUNTRIES) if game["level"] == "all" else len(pool)
        send(token, chat_id, f"🎉 Уровень «{level_name}» пройден! Вы изучили все {total} флагов. Одиночный режим не добавляет очки в общий счёт.")
        return

    target = random.choice(unused)
    distractors = [c for c in pool if c["iso"] != target["iso"]]
    options = random.sample(distractors, 3) + [target]
    random.shuffle(options)
    game["round"] += 1
    game["used"].add(target["iso"])
    game["answer"] = target
    game["options"] = options
    game["answered"] = False
    game["round_hints"] = 0

    result = call(token, "sendPhoto", {
        "chat_id": chat_id,
        "photo": f"https://flagcdn.com/w320/{target['iso']}.png",
        "caption": f"👤 {level_name} • вопрос {game['round']}\nНазовите страну по флагу. У вас 15 секунд!",
        "reply_markup": json.dumps(solo_answer_keyboard(options), ensure_ascii=False),
    })
    game["prompt_message_id"] = (result.get("result") or {}).get("message_id")
    game["deadline"] = time.time() + 15


def start_round(token: str, chat_id: int, game: dict) -> None:
    if game.get("mode") == "solo":
        start_solo_round(token, chat_id, game)
        return
    game["round"] += 1
    level, pool = difficulty_pool(game["round"])
    choices = [c for c in pool if c["iso"] not in game["used"]]
    if not choices:
        game["used"].clear()
        choices = pool or COUNTRIES[:]
    country = random.choice(choices)
    game["used"].add(country["iso"])
    game["answer"] = country
    game["answered"] = False
    game["round_hints"] = 0
    flag_url = f"https://flagcdn.com/w320/{country['iso']}.png"
    call(token, "sendPhoto", {
        "chat_id": chat_id,
        "photo": flag_url,
        "caption": f"🌍 Раунд {game['round']} • {level} сложность\nУгадайте страну только по флагу! Ответьте названием страны.",
        "reply_markup": json.dumps(GAME_KEYBOARD, ensure_ascii=False),
    })


def close_solo_buttons(token: str, chat_id: int, game: dict) -> None:
    message_id = game.get("prompt_message_id")
    if message_id:
        call(token, "editMessageReplyMarkup", {
            "chat_id": chat_id,
            "message_id": message_id,
            "reply_markup": json.dumps({"inline_keyboard": []}),
        })


def submit_solo_choice(token: str, chat_id: int, game: dict, selected_iso: str) -> None:
    if game.get("answered") or game.get("finished") or selected_iso not in {c["iso"] for c in game.get("options", [])}:
        return
    if time.time() >= game.get("deadline", 0):
        game["answered"] = True
        close_solo_buttons(token, chat_id, game)
        send(token, chat_id, f"⏰ Время вышло! Это {game['answer']['name']}.")
        start_solo_round(token, chat_id, game)
        return
    close_solo_buttons(token, chat_id, game)
    if selected_iso == game["answer"]["iso"]:
        send(token, chat_id, "✅ Верно! Следующий флаг.")
    else:
        send(token, chat_id, f"❌ Не угадали. Это {game['answer']['name']}. Следующий флаг.")
    game["answered"] = True
    start_solo_round(token, chat_id, game)


def expire_solo_rounds(token: str) -> None:
    now = time.time()
    for chat_id, game in list(GAMES.items()):
        if game.get("mode") == "solo" and not game.get("answered") and not game.get("finished") and now >= game.get("deadline", float("inf")):
            game["answered"] = True
            close_solo_buttons(token, chat_id, game)
            send(token, chat_id, f"⏰ Время вышло! Это {game['answer']['name']}.")
            start_solo_round(token, chat_id, game)


def handle(token: str, message: dict) -> None:
    chat_id = message["chat"]["id"]
    user = message.get("from", {})
    name = user.get("first_name") or "Игрок"
    text = (message.get("text") or "").strip()
    command = text.split()[0].split("@")[0].lower() if text.startswith("/") else ""

    # This one onboarding command reveals only the caller's own Telegram ID.
    if command == "/myid":
        send(token, chat_id, f"Ваш Telegram ID: {user.get('id')}\nДобавьте его в ALLOWED_USER_IDS, чтобы разрешить игру.")
        return
    if user.get("id") not in ALLOWED_USERS:
        return

    active_game = GAMES.get(chat_id)
    if active_game and active_game.get("mode") in ("solo", "solo_setup") and active_game.get("owner") != user.get("id"):
        return

    if command in ("/start", "/help", "/main_menu"):
        send(token, chat_id, "Главное меню — начните игру или посмотрите счёт.", MAIN_MENU_KEYBOARD)
        return
    if command == "/choose_mode":
        send(token, chat_id, "Выберите режим игры:", MODE_MENU_KEYBOARD)
        return
    if command == "/menu_score":
        current = GAMES.get(chat_id)
        if current and current.get("mode") == "solo":
            text = "Одиночная тренировка не входит в общий игровой счёт."
        elif current and current.get("mode") == "duo":
            text = score_text(current)
        else:
            text = "Пока нет активной игры и счёта."
        send(token, chat_id, text, MAIN_MENU_KEYBOARD)
        return
    if command == "/solo":
        GAMES[chat_id] = {"mode": "solo_setup", "owner": user.get("id"), "scores": {}, "names": {}}
        send(token, chat_id, "👤 Одиночная игра — выберите уровень:\nНачальный: самые знакомые флаги. Средний: остальные страны. Продвинутый: территории. «Все флаги» проходит этапы от простых к редким. В каждом вопросе 1 флаг, 4 варианта и 15 секунд.", SOLO_LEVEL_KEYBOARD)
        return
    if command in ("/solo_easy", "/solo_medium", "/solo_hard", "/solo_all"):
        setup = GAMES.get(chat_id)
        level_key = command.removeprefix("/solo_")
        if not setup or setup.get("mode") != "solo_setup" or setup.get("owner") != user.get("id"):
            send(token, chat_id, "Сначала нажмите «Одиночная игра» и выберите уровень.")
            return
        GAMES[chat_id] = {
            "mode": "solo", "owner": user.get("id"), "level": level_key,
            "scores": {user.get("id"): 0}, "names": {user.get("id"): name},
            "used": set(), "round": 0, "answer": None, "answered": False,
            "hints_left": 5, "round_hints": 0, "finished": False,
        }
        send(token, chat_id, f"Начинаем одиночное обучение: {level_key}. Угадывайте флаг!")
        start_round(token, chat_id, GAMES[chat_id])
        return
    if command == "/newgame":
        GAMES[chat_id] = {"mode": "duo", "scores": {}, "names": {}, "used": set(), "round": 0, "answer": None, "answered": False, "hints_left": 5}
        send(token, chat_id, "🎉 Новая игра! Зовите друг друга и отвечайте в этом чате. Начинаем!")
        start_round(token, chat_id, GAMES[chat_id])
        return
    game = GAMES.get(chat_id)
    if game and game.get("mode") == "solo_setup" and not command:
        send(token, chat_id, "Выберите один из уровней в меню выше:", SOLO_LEVEL_KEYBOARD)
        return
    if command == "/solo_answer":
        selected_iso = text.split(maxsplit=1)[1].strip().lower() if len(text.split(maxsplit=1)) > 1 else ""
        if game and game.get("mode") == "solo":
            submit_solo_choice(token, chat_id, game, selected_iso)
        return
    if command == "/stop":
        if game:
            if game.get("mode") == "solo":
                close_solo_buttons(token, chat_id, game)
            GAMES.pop(chat_id, None)
            if game.get("mode") == "solo":
                send(token, chat_id, "Одиночная тренировка завершена. Она не входит в общий счёт.")
            else:
                send(token, chat_id, "Игра завершена!\n" + score_text(game))
        else:
            send(token, chat_id, "Сейчас нет активной игры. Напишите /newgame, чтобы начать.")
        return
    if command == "/score":
        if game and game.get("mode") == "solo":
            send(token, chat_id, "Одиночная тренировка не входит в общий игровой счёт.")
        else:
            send(token, chat_id, score_text(game) if game else "Сейчас нет активной игры. Напишите /newgame.")
        return
    if command == "/next":
        if game and game.get("answer") and not game.get("finished"):
            answer = game["answer"]
            if game.get("mode") == "solo":
                close_solo_buttons(token, chat_id, game)
                game["answered"] = True
            send(token, chat_id, f"Ответ: {answer['name']} {answer['flag']}. Следующий раунд!")
            start_round(token, chat_id, game)
        elif game and game.get("finished"):
            send(token, chat_id, "Этот уровень уже завершён. Нажмите «Одиночная игра», чтобы выбрать другой.")
        else:
            send(token, chat_id, "Сначала начните игру командой /newgame.")
        return
    if command == "/hint":
        if not game or not game.get("answer"):
            send(token, chat_id, "Сначала начните игру командой /newgame или выберите уровень в одиночной игре.")
        elif game.get("finished"):
            send(token, chat_id, "Уровень уже завершён — выберите другой режим.")
        elif game["answered"]:
            send(token, chat_id, "Раунд уже завершён — дождитесь следующего флага.")
        elif game["hints_left"] <= 0:
            send(token, chat_id, "Подсказки на эту игру закончились — вы уже использовали все 5.")
        else:
            answer = game["answer"]
            normalized_name = "".join(char for char in answer["name"] if char.isalpha())
            step = game.get("round_hints", 0) + 1
            game["round_hints"] = step
            game["hints_left"] -= 1
            if step == 1:
                clue = f"В названии {len(normalized_name)} букв."
            elif step == 2:
                clue = f"Название начинается на «{normalized_name[:1]}»."
            elif step == 3:
                clue = f"Первые две буквы: «{normalized_name[:2]}»."
            elif step == 4:
                clue = f"Первые три буквы: «{normalized_name[:3]}»."
            else:
                clue = f"Столица этой страны — {answer['capital']}."
            send(token, chat_id, f"💡 Подсказка {step}/5: {clue} Осталось подсказок на игру: {game['hints_left']} из 5.")
        return
    if not game or not text or text.startswith("/"):
        return

    normalize = lambda value: " ".join(value.casefold().replace("ё", "е").strip(" .,!?«»\"'").split())
    if game.get("mode") == "solo":
        chosen = next((c for c in game.get("options", []) if normalize(text) == normalize(c["name"])), None)
        if chosen:
            submit_solo_choice(token, chat_id, game, chosen["iso"])
        return

    answer = game["answer"]
    accepted = normalize(answer["name"])
    if not game["answered"] and normalize(text) == accepted:
        game["answered"] = True
        game["names"][user.get("id", name)] = name
        game["scores"][user.get("id", name)] = game["scores"].get(user.get("id", name), 0) + 1
        send(token, chat_id, f"✅ Верно, {name}! Это {answer['name']} {answer['flag']}. +1 очко\n\n" + score_text(game))
        time.sleep(1)
        start_round(token, chat_id, game)


def score_text(game: dict | None) -> str:
    if not game or not game["scores"]:
        return "Счёт пока пуст — пусть первым ответит кто-нибудь из вас!"
    rows = sorted(game["scores"].items(), key=lambda item: (-item[1], game["names"].get(item[0], "")))
    return "🏆 Счёт:\n" + "\n".join(f"{game['names'].get(uid, 'Игрок')} — {score}" for uid, score in rows)


def handle_callback(token: str, query: dict) -> None:
    call(token, "answerCallbackQuery", {"callback_query_id": query["id"]})
    message = query.get("message")
    data = query.get("data", "")
    if not message:
        return
    if data in {"start", "newgame", "solo", "back_menu", "level_easy", "level_medium", "level_hard", "level_all"}:
        call(token, "editMessageReplyMarkup", {
            "chat_id": message["chat"]["id"],
            "message_id": message["message_id"],
            "reply_markup": json.dumps({"inline_keyboard": []}),
        })
    if data.startswith("solo_answer:"):
        command = "/solo_answer " + data.split(":", 1)[1]
    else:
        command = BUTTON_COMMANDS.get(data)
    if not command:
        return
    # Reuse the normal command path so permissions and game rules stay identical.
    handle(token, {**message, "from": query.get("from", {}), "text": command})


def main() -> None:
    global ALLOWED_USERS
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not token:
        raise SystemExit("Set TELEGRAM_BOT_TOKEN to your bot token from @BotFather.")
    try:
        ids = {int(part.strip()) for part in os.environ.get("ALLOWED_USER_IDS", "").split(",") if part.strip()}
    except ValueError:
        raise SystemExit("ALLOWED_USER_IDS must contain numeric Telegram user IDs separated by a comma.")
    if len(ids) not in (0, 2):
        raise SystemExit("ALLOWED_USER_IDS must be empty for initial ID discovery, or contain exactly two Telegram user IDs.")
    ALLOWED_USERS = ids
    if ids:
        print("Country game bot is running with a two-user allowlist. Press Ctrl+C to stop.")
    else:
        print("ID discovery mode: only /myid replies; no gameplay is allowed until two IDs are configured.")
    offset = 0
    while True:
        updates = call(token, "getUpdates", {
            "timeout": 5,
            "offset": offset,
            "allowed_updates": json.dumps(["message", "callback_query"]),
        })
        if "result" not in updates:
            time.sleep(3)
            continue
        for update in updates.get("result", []):
            offset = update["update_id"] + 1
            if update.get("callback_query"):
                try:
                    handle_callback(token, update["callback_query"])
                except Exception as exc:
                    print(f"Callback handling error: {exc}")
                continue
            message = update.get("message")
            if message:
                try:
                    handle(token, message)
                except Exception as exc:
                    print(f"Update handling error: {exc}")
        try:
            expire_solo_rounds(token)
        except Exception as exc:
            print(f"Solo timer error: {exc}")


if __name__ == "__main__":
    main()
